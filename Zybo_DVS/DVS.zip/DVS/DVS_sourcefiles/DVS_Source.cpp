#include "DVS_Source.hpp"

void DVS(AXI_STREAM& INPUT_STREAM, AXI_STREAM& OUTPUT_STREAM, uint8_t readImage[409600], uint8_t writeImage[409600])
{
	#pragma HLS INTERFACE axis port=INPUT_STREAM
	#pragma HLS INTERFACE axis port=OUTPUT_STREAM
	#pragma HLS INTERFACE bram port=writeImage
	#pragma HLS INTERFACE bram port=readImage
	#pragma HLS RESOURCE variable=writeImage core=RAM_1P_BRAM
	#pragma HLS RESOURCE variable=readImage core=RAM_1P_BRAM

	RGB_IMAGE img_in(MAX_HEIGHT, MAX_WIDTH);
	GREY_IMAGE img_grey(MAX_HEIGHT, MAX_WIDTH);
	GREY_IMAGE_RESIZE img_resize(QH, QW);
	GREY_IMAGE_RESIZE img_dl(QH, QW);
	GREY_IMAGE_RESIZE img_d2(QH, QW);
	GREY_IMAGE_RESIZE img_read(QH,QW);
	GREY_IMAGE_RESIZE img_abs(QH,QW);
	GREY_IMAGE_RESIZE img_final(QH, QW);
	int thresh = 16;
	int maxval = 255;
	
	#pragma HLS dataflow
	hls::AXIvideo2Mat(INPUT_STREAM, img_in);	//input 1280x720 image RGB image
	hls::CvtColor<HLS_RGB2GRAY>(img_in, img_grey);	//convert to greyscale
	hls::Resize(img_grey, img_resize);		//resize to 640x640

	//Previous image required for DVS calculation
	//Difference of current and previous frames
	//Previous frame read from BRAM memory as img_read
	//Current frame then stored in same memory location for next iteration
	hls::Duplicate(img_resize, img_dl, img_d2);	//d1 for absDiff, d2 to be written to BRAM
	hls::Array2Mat<QW, uint8_t, QH, QW, HLS_8UC1>(readImage, img_read);
	hls::Mat2Array<QW, uint8_t, QH, QW, HLS_8UC1>(img_d2, writeImage);

	//Current frame differenced against previous frame - only store changes
	//This creates small noisy differences on each pixel
	//Threshold used to find big enough changes to count as a 'change'
	//Changes stored as 255, everything else as 0
	hls::AbsDiff(img_dl,img_read,img_abs);
	hls::Threshold(img_abs,img_final,thresh,maxval,HLS_THRESH_BINARY);

	hls::Mat2AXIvideo(img_final,OUTPUT_STREAM);		//output as 640x640 greyscale image
}
