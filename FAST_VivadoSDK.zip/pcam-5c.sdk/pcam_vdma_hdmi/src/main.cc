#include "xparameters.h"

#include "platform/platform.h"
#include "ov5640/OV5640.h"
#include "ov5640/ScuGicInterruptController.h"
#include "ov5640/PS_GPIO.h"
#include "ov5640/AXI_VDMA.h"
#include "ov5640/PS_IIC.h"

#include "MIPI_D_PHY_RX.h"
#include "MIPI_CSI_2_RX.h"

#include "PmodWIFI.h"
#include "PmodPIR.h"

#include "xil_cache.h"
#include "xuartps.h"

#ifdef __MICROBLAZE__
#define PMODWIFI_VEC_ID XPAR_INTC_0_PMODWIFI_0_VEC_ID
#else
#define PMODWIFI_VEC_ID XPAR_FABRIC_PMODWIFI_0_WF_INTERRUPT_INTR
#endif

#define UART_BASEADDR 			XPAR_PS7_UART_1_BASEADDR
#define IRPT_CTL_DEVID 		XPAR_PS7_SCUGIC_0_DEVICE_ID
#define GPIO_DEVID			XPAR_PS7_GPIO_0_DEVICE_ID
#define GPIO_IRPT_ID			XPAR_PS7_GPIO_0_INTR
#define CAM_I2C_DEVID		XPAR_PS7_I2C_0_DEVICE_ID
#define CAM_I2C_IRPT_ID		XPAR_PS7_I2C_0_INTR
#define VDMA_DEVID			XPAR_AXIVDMA_0_DEVICE_ID
#define VDMA_MM2S_IRPT_ID	XPAR_FABRIC_AXI_VDMA_0_MM2S_INTROUT_INTR
#define VDMA_S2MM_IRPT_ID	XPAR_FABRIC_AXI_VDMA_0_S2MM_INTROUT_INTR
#define CAM_I2C_SCLK_RATE	100000

#define DDR_BASE_ADDR		XPAR_DDR_MEM_BASEADDR
#define MEM_BASE_ADDR		(DDR_BASE_ADDR + 0x0A000000)

#define GAMMA_BASE_ADDR     XPAR_AXI_GAMMACORRECTION_0_BASEADDR

using namespace digilent;


/************************************************************************/
/*                                                                      */
/*              SET THESE VALUES FOR YOUR NETWORK                       */
/*                                                                      */
/************************************************************************/

const char *szIPServer = "192.168.1.154"; // Server to connect to
uint16_t portServer = DEIPcK::iPersonalPorts44 + 300; // Port 44300

// Specify the SSID
const char *szSsid = "Onestream-TNCAPF2C51D";

// Select 1 for the security you want, or none for no security
#define USE_WPA2_PASSPHRASE
//#define USE_WPA2_KEY
//#define USE_WEP40
//#define USE_WEP104
//#define USE_WF_CONFIG_H

// Modify the security key to what you have.
#if defined(USE_WPA2_PASSPHRASE)

   const char *szPassPhrase = "DKQ6QTF3";
   #define WiFiConnectMacro() deIPcK.wfConnect(szSsid, szPassPhrase, &status)

#elif defined(USE_WPA2_KEY)

   WPA2KEY key = { 0x27, 0x2C, 0x89, 0xCC, 0xE9, 0x56, 0x31, 0x1E,
                   0x3B, 0xAD, 0x79, 0xF7, 0x1D, 0xC4, 0xB9, 0x05,
                   0x7A, 0x34, 0x4C, 0x3E, 0xB5, 0xFA, 0x38, 0xC2,
                   0x0F, 0x0A, 0xB0, 0x90, 0xDC, 0x62, 0xAD, 0x58 };
   #define WiFiConnectMacro() deIPcK.wfConnect(szSsid, key, &status)

#elif defined(USE_WEP40)

   const int iWEPKey = 0;
   WEP40KEY keySet = { 0xBE, 0xC9, 0x58, 0x06, 0x97,   // Key 0
                       0x00, 0x00, 0x00, 0x00, 0x00,   // Key 1
                       0x00, 0x00, 0x00, 0x00, 0x00,   // Key 2
                       0x00, 0x00, 0x00, 0x00, 0x00 }; // Key 3
   #define WiFiConnectMacro() deIPcK.wfConnect(szSsid, keySet, iWEPKey, &status)

#elif defined(USE_WEP104)

   const int iWEPKey = 0;
   WEP104KEY keySet = { 0x3E, 0xCD, 0x30, 0xB2, 0x55, 0x2D, 0x3C, 0x50, 0x52, 0x71, 0xE8, 0x83, 0x91,   // Key 0
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // Key 1
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // Key 2
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }; // Key 3
   #define WiFiConnectMacro() deIPcK.wfConnect(szSsid, keySet, iWEPKey, &status)

#elif defined(USE_WF_CONFIG_H)

   #define WiFiConnectMacro() deIPcK.wfConnect(0, &status)

#else // No security - OPEN

   #define WiFiConnectMacro() deIPcK.wfConnect(szSsid, &status)

#endif

//******************************************************************************************
//******************************************************************************************
//***************************** END OF CONFIGURATION ***************************************
//******************************************************************************************
//******************************************************************************************

typedef enum {
   NONE = 0,
   CONNECT,
   PIR,
   TCPCONNECT,
   WRITE,
   READ,
   CLOSE,
   DONE,
} STATE;

STATE state = CONNECT;

unsigned tStart = 0;
unsigned tWait = 200; // Waiting for a reply from the TCP Server

TCPSocket tcpSocket;
byte rgbRead[1024];


/*** Global Variables ***/
//VDMA and Image buffer setup
const int width = 640;
const int height = 640;
#define channels 3 // Grayscale image in VDMA has 3 channels
#define FRAME_STRIDE (width * channels)
unsigned int srcBuffer = MEM_BASE_ADDR;
u8 buffer[width*height]; // Buffer used to store a DVS frame from VDMA
int cbbuffer = sizeof(buffer);
const int TCP_CLIENT_BUFFER = 2048; // TCP Packet size

PmodPIR myDevice;
void WiFiInitialize();
void WiFiRun(AXI_VDMA<ScuGicInterruptController>& vdma_driver);

void pipeline_mode_change(AXI_VDMA<ScuGicInterruptController>& vdma_driver, OV5640& cam, VideoOutput& vid, Resolution res, OV5640_cfg::mode_t mode)
{
	//Bring up input pipeline back-to-front
	{
		vdma_driver.resetWrite();
		MIPI_CSI_2_RX_mWriteReg(XPAR_MIPI_CSI_2_RX_0_S_AXI_LITE_BASEADDR, CR_OFFSET, (CR_RESET_MASK & ~CR_ENABLE_MASK));
		MIPI_D_PHY_RX_mWriteReg(XPAR_MIPI_D_PHY_RX_0_S_AXI_LITE_BASEADDR, CR_OFFSET, (CR_RESET_MASK & ~CR_ENABLE_MASK));
		cam.reset();
	}

	{
		vdma_driver.configureWrite(width, height);
		Xil_Out32(GAMMA_BASE_ADDR, 0); // Set Gamma correction factor to 1
		cam.init();
	}

	{
		vdma_driver.enableWrite();
		MIPI_CSI_2_RX_mWriteReg(XPAR_MIPI_CSI_2_RX_0_S_AXI_LITE_BASEADDR, CR_OFFSET, CR_ENABLE_MASK);
		MIPI_D_PHY_RX_mWriteReg(XPAR_MIPI_D_PHY_RX_0_S_AXI_LITE_BASEADDR, CR_OFFSET, CR_ENABLE_MASK);
		cam.set_mode(mode);
		cam.set_awb(OV5640_cfg::awb_t::AWB_DISABLED);
	}

	//Bring up output pipeline back-to-front
	{
		vid.reset();
		vdma_driver.resetRead();
	}

	{
		vid.configure(res);
		vdma_driver.configureRead(width, height);
	}

	{
		vid.enable();
		vdma_driver.enableRead();
	}
}

void Stop_Read_Start(AXI_VDMA<ScuGicInterruptController>& vdma_driver)
{
	// This function is used to read in a VDMA frame and store it in the buffer array
	xil_printf("Creating Payload Buffer... \r\n");
	vdma_driver.disableWrite();
	vdma_driver.disableRead();
	Xil_DCacheFlushRange((unsigned int) (srcBuffer), FRAME_STRIDE);
	u32 xcoi, ycoi;
	u32 lineStart = 0;
	u32 stride = FRAME_STRIDE;
	for(ycoi = 0; ycoi < height; ycoi++)
	{
		for(xcoi = 0; xcoi < stride; xcoi+=3)
		{
			buffer[(xcoi + lineStart)/3] = Xil_In8(srcBuffer + xcoi + lineStart); //Grayscale
		}
		lineStart += stride;
	}
	xil_printf("Buffer Created\r\n");

	vdma_driver.enableWrite();
	vdma_driver.enableRead();
}

int main()
{
	// Setup and initialization
	init_platform();
	ScuGicInterruptController irpt_ctl(IRPT_CTL_DEVID);
	PS_GPIO<ScuGicInterruptController> gpio_driver(GPIO_DEVID, irpt_ctl, GPIO_IRPT_ID);
	PS_IIC<ScuGicInterruptController> iic_driver(CAM_I2C_DEVID, irpt_ctl, CAM_I2C_IRPT_ID, 100000);
	OV5640 cam(iic_driver, gpio_driver);
	AXI_VDMA<ScuGicInterruptController> vdma_driver(VDMA_DEVID, MEM_BASE_ADDR, irpt_ctl,
			VDMA_MM2S_IRPT_ID,
			VDMA_S2MM_IRPT_ID);
	VideoOutput vid(XPAR_VTC_0_DEVICE_ID, XPAR_VIDEO_DYNCLK_DEVICE_ID);
	// Pcam 5C Camera configuration
	pipeline_mode_change(vdma_driver, cam, vid, Resolution::R640_480_60_NN, OV5640_cfg::mode_t::MODE_720P_1280_720_60fps);
	PIR_begin(&myDevice, XPAR_PMODPIR_0_AXI_LITE_GPIO_BASEADDR);

	xil_printf("Main Start...\r\n");

	Xil_ICacheEnable();
	Xil_DCacheEnable();

	xil_printf("\nInitializing the WiFi TCP Client...\r\n");
	WiFiInitialize();
	WiFiRun(vdma_driver);

	return 0;
}

void WiFiInitialize() {
   setPmodWifiAddresses(
      XPAR_PMODWIFI_0_AXI_LITE_SPI_BASEADDR,
      XPAR_PMODWIFI_0_AXI_LITE_WFGPIO_BASEADDR,
      XPAR_PMODWIFI_0_AXI_LITE_WFCS_BASEADDR,
      XPAR_PMODWIFI_0_S_AXI_TIMER_BASEADDR
   );
   setPmodWifiIntVector(PMODWIFI_VEC_ID);
}

void WiFiRun(AXI_VDMA<ScuGicInterruptController>& vdma_driver) {
   IPSTATUS status;
   int cbRead = 0;
   u32 PIRstate=0;
   int pixel_counter=0; // Counts the number of transmitted pixels
   byte Payload_buffer[TCP_CLIENT_BUFFER]; //The TCP payload
   int i = 0;
   int Tx_Start = 0;
   int Tx_End = 0;
   while (1) {
      switch (state) {
      case CONNECT: //Connect to WLAN
         if (WiFiConnectMacro()) {
            xil_printf("WiFi connected\r\n");
            deIPcK.begin();
            state = PIR;
         } else if (IsIPStatusAnError(status)) {
            xil_printf("Unable to connect, status: %d\r\n", status);
            state = CLOSE;
         }
         break;

      case PIR: //Check the PIR
		xil_printf("PIR pending...\r\n");
		PIRstate=0;
		pixel_counter=0;
		cbRead = 0;
  		while (PIRstate!=1)
  		{
  		PIRstate = PIR_getState(&myDevice);
  			if(PIRstate==1)
  			{
  			xil_printf("PIR Movement Detected,Starting WiFi transmission!\r\n");
  			Stop_Read_Start(vdma_driver);
  			state = TCPCONNECT;
  			}
  		}
    	  break;

      case TCPCONNECT: //Connect to the TCP Server
    	 if (deIPcK.tcpConnect(szIPServer, portServer, tcpSocket)) {
            xil_printf("Connected to the TCP server.\r\n");
            Tx_Start= (unsigned) SYSGetSecond();
            state = WRITE;
         }
         break;

	 case WRITE: //Transmit the TCP payload
		if (tcpSocket.isEstablished()) {
			for(i=0;i<TCP_CLIENT_BUFFER-1;i++){
				Payload_buffer[i]=buffer[i+pixel_counter];
				// fills the TCP payload with the next TCP_CLIENT_BUFFER elements
			}
			pixel_counter=pixel_counter+TCP_CLIENT_BUFFER; // Increments the pixel counter
		    tcpSocket.writeStream(Payload_buffer, sizeof(Payload_buffer)); // Sends the TCP payload
		    state = READ;
		    tStart = (unsigned) SYSGetMilliSecond();
		}
		break;

	 // Look for the echo back
	 case READ:
		// See if we got anything to read
		if ((cbRead = tcpSocket.available()) > 0) {
		   cbRead = cbRead < (int) sizeof(rgbRead) ? cbRead : sizeof(rgbRead);
		   cbRead = tcpSocket.readStream(rgbRead, cbRead);
		   rgbRead[cbRead] = 0; // Null Terminator
		   //xil_printf("%s\r\n", rgbRead);
		}

		// Give us some time to get everything echo'ed back
		else if ((((unsigned) SYSGetMilliSecond()) - tStart) > tWait) {
		   state = CLOSE;
		}
		break;

      // Done, so close up the tcpSocket
      case CLOSE:
          if(pixel_counter<(width*height)) state = WRITE;
          else{
              xil_printf("Image Sent!\r\n");
              tcpSocket.close();
              xil_printf("Finished transmission, closing connection.\r\n");
              Tx_End = (unsigned) SYSGetSecond();
              state = DONE;
          }
         break;

      case DONE:// Calculates transmission duration of one DVS frame and jumps back to PIR state
    	  xil_printf("Elapsed time: %d s\r\n" ,(Tx_End - Tx_Start));
    	  state = PIR;
    	  break;

      default:
         break;
      }

      // Keep the stack alive each pass through the loop()
      DEIPcK::periodicTasks();
   }
}
